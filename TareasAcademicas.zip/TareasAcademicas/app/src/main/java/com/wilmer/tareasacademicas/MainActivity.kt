
package com.wilmer.tareasacademicas

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.clickable
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class Tarea(
    val id: Int,
    val titulo: String,
    val asignatura: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            MaterialTheme {
                PantallaTareas()
            }
        }
    }
}

@Composable
fun PantallaTareas() {

    var titulo by remember { mutableStateOf("") }
    var asignatura by remember { mutableStateOf("") }
    var siguienteId by remember { mutableIntStateOf(3) }
    var tareaSeleccionadaId by remember { mutableStateOf<Int?>(null) }
    var mensajeError by remember { mutableStateOf("") }
    var editandoTareaId by remember { mutableStateOf<Int?>(null) }

    val tareas = remember {
        mutableStateListOf(
            Tarea(1, "Investigar Android", "Programación"),
            Tarea(2, "Resolver ejercicios", "Matemáticas")
        )
    }

    if (tareaSeleccionadaId == null) {

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp)
        ) {

            Text(
                text = "Asignaciones Universitarias",
                style = MaterialTheme.typography.headlineMedium
            )

            Spacer(modifier = Modifier.height(20.dp))

            OutlinedTextField(
                value = titulo,
                onValueChange = { titulo = it },
                label = { Text("Nombre de la tarea") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = asignatura,
                onValueChange = { asignatura = it },
                label = { Text("Asignatura") },
                modifier = Modifier.fillMaxWidth()
            )

            if (mensajeError.isNotEmpty()) {
                Text(
                    text = mensajeError,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            if (editandoTareaId != null) {
                Text(
                    text = "Editando tarea",
                    style = MaterialTheme.typography.titleMedium
                )
            }

            Button(
                onClick = {
                    if (titulo.isBlank() || asignatura.isBlank()) {
                        mensajeError = "Completa todos los campos."
                    } else {
                        if (editandoTareaId == null) {

                            tareas.add(
                                Tarea(siguienteId, titulo, asignatura)
                            )
                            siguienteId++
                            mensajeError = "Tarea agregada correctamente."

                        } else {

                            val indice = tareas.indexOfFirst {
                                it.id == editandoTareaId
                            }

                            if (indice != -1) {
                                tareas[indice] = Tarea(
                                    editandoTareaId!!,
                                    titulo,
                                    asignatura
                                )
                                mensajeError = "Tarea actualizada correctamente."
                            }

                            editandoTareaId = null
                        }

                        titulo = ""
                        asignatura = ""
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    if (editandoTareaId == null)
                        "Agregar tarea"
                    else
                        "Guardar cambios"
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "Lista de tareas",
                style = MaterialTheme.typography.titleLarge
            )

            LazyColumn {
                items(tareas) { tarea ->

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 5.dp)
                            .clickable {
                                tareaSeleccionadaId = tarea.id
                            }
                    ) {
                        Column(
                            modifier = Modifier.padding(15.dp)
                        ) {
                            Text(text = tarea.titulo)
                            Text(text = tarea.asignatura)
                        }
                    }
                }
            }
        }

    } else {

        val tareaSeleccionada = tareas.firstOrNull {
            it.id == tareaSeleccionadaId
        }

        PantallaDetalle(
            tarea = tareaSeleccionada,
            onVolver = {
                tareaSeleccionadaId = null
            },
            onEliminar = {
                tareas.removeAll {
                    it.id == tareaSeleccionadaId
                }
                tareaSeleccionadaId = null
            },
            onEditar = {
                if (tareaSeleccionada != null) {
                    titulo = tareaSeleccionada.titulo
                    asignatura = tareaSeleccionada.asignatura
                    editandoTareaId = tareaSeleccionada.id
                    tareaSeleccionadaId = null
                    mensajeError = ""
                }
            }
        )
    }
}

@Composable
fun PantallaDetalle(
    tarea: Tarea?,
    onVolver: () -> Unit,
    onEliminar: () -> Unit,
    onEditar: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp)
    ) {

        Text(
            text = "Detalles de la tarea",
            style = MaterialTheme.typography.headlineMedium
        )

        Spacer(modifier = Modifier.height(20.dp))

        if (tarea != null) {

            Text(text = "ID: ${tarea.id}")

            Text(text = "Nombre: ${tarea.titulo}")

            Text(text = "Asignatura: ${tarea.asignatura}")

        } else {

            Text(text = "No se encontró la tarea.")
        }

        Spacer(modifier = Modifier.height(20.dp))

        Button(onClick = onVolver) {
            Text("Volver")
        }

        Button(onClick = onEditar) {
            Text("Editar tarea")
        }

        Button(
            onClick = onEliminar,
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.error
            )
        ) {
            Text("Eliminar tarea")
        }
    }
}
